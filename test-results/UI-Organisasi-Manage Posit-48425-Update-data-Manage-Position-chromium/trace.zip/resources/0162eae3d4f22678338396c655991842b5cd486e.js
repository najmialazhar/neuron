var site_url = '<?php echo site_url(); ?>';
var loader = '<div class="loader"><div class="wrapper-image loader-icon"><img src="assets/img/other/loader.svg" /></div></div>';
var window_height;
var window_width;

function getHeightWidth() {
    window_height = $(window).height();
    window_width = $(window).width();
}

function sidebarCondition() {
    if (window_width < 992) {
        $(".sidebar-left").addClass("collapsed");
        $(".collapse-sidebar-button").attr('aria-hidden', 'true');
    } else {
        $(".sidebar-left").removeClass("collapsed");
        $(".collapse-sidebar-button").attr('aria-hidden', 'false');
    }
}

$(window).on("load", function() {
    getHeightWidth();
    $(".carousel .carousel-item>div").css("height", window_height);
    $(".modal-footer .btn").addClass("btn-md");

    $("body,html,document").animate({
        scrollTop: 0
    }, 1000);

    $(".main-body").animate({
        scrollTop: 0
    }, 1000);

    sidebarCondition();
});

$(function() {
    /* bootstrap */
    $('[data-toggle="tooltip"]').tooltip({
        boundary: 'window'
    });
    $('[data-toggle="popover"]').popover();
    $('[data-toggle="dropdown"]').dropdown();

    /* Button show password */
    $("#btn_show_password").on("click", function() {
        var type = $(".input-password").attr("type");
        if (type == 'password') {
            $(".input-password").attr("type", "text");
        } else {
            $(".input-password").attr("type", "password");
        }
    });
    /* End button show password */

    /* carousel height */
    $(window).on("resize", function() {
        getHeightWidth();
        $(".carousel .carousel-item>div").css("height", window_height);

        sidebarCondition();
    });
    /* End carousel height */

    /* Select 2 */
    $(".select-2").select2({
        theme: 'bootstrap'
    });
    /* End select 2 */

    /* Datepicker */
    $('.datepicker-here').datepicker();
    /* End Datepicker */

    /* Notiflix */
    Notiflix.Notify.Init({
        position: 'right-top',
    });
    /* End Notiflix */

    /* Datatable */
    $(".datatable").dataTable();
    /* End Datatable */

    /* Smart Wizard */
    // $('.smart_wizard').smartWizard({
    //     selected: 0,
    //     theme: 'dots',
    //     transitionEffect: 'fade',
    //     showStepURLhash: false,
    // });
    /* End Smart Wizard */

    /* Close button */
    $(".close").on("click", function() {
        var target = $(this).data("target");
        $(target).fadeOut(200);
    });
    /* End close button */

    /* Toggle View */
    $("#btn_toggle_view").on("click", function() {
        var btnToggle = $(this);
        var condition = btnToggle.attr("data-condition");
        if (condition == "max") {
            $("body").addClass("body-max");
            $(btnToggle).attr("data-condition", "min");
        } else if (condition == "min") {
            $("body").removeClass("body-max");
            $(btnToggle).attr("data-condition", "max");
        }
    });
    /* End Toggle View */

    /* Logo type select */
    $("#logo_type_select").on("change", function() {
        var choosen = $(this).val();
        $(".logo-group").removeClass("active");
        switch (choosen) {
            case 'fullLogo':
                $("#" + choosen).addClass("active");
                break;
            case 'markLogo':
                $("#" + choosen).addClass("active");
                break;
            default:
                Swal.fire(
                    'Something wrong!',
                    'There is something wrong with the option, please contact our administrator.',
                    'warning'
                );
        }
    });

    /* Color option */
    $(".color-option").on("click", function() {
        var target = $(this).data("color");
        $(".color-option").removeClass("active");
        $(this).addClass("active");
        $("#color_picker").val(target + "-theme");
        $("body").attr("class", "").addClass(target + "-theme");
    });

    /* Card chosen */
    $(".card-chosen").on("click", function() {
        var target = $(this).data("type");
        $(".card-chosen").removeClass("active");
        $("#config_chosen").val(target);
        $(this).addClass("active");
    });

    /* Collapse sidebar */
    $(".collapse-sidebar-button").on("click", function(e) {
        e.preventDefault();
        var this_button = $(".collapse-sidebar-button");
        var aria = this_button.attr('aria-hidden');

        if (aria == 'true') {
            $(".sidebar-left").removeClass("collapsed");
            this_button.attr('aria-hidden', 'false');
        } else if (aria == 'false') {
            $(".sidebar-left").addClass("collapsed");
            this_button.attr('aria-hidden', 'true');
        }
    });

    $("#triggerCollapseSidebar").on("click", function(e) {
        e.preventDefault();
        $(".collapse-sidebar-button").trigger('click');
    });

    $(".sidebar-left .btn-trigger").on("click", function() {
        $(".sidebar-menu").toggleClass("show");
    });

    /* Scroll Top */
    $('.main-body').on("scroll", function() {
        var state = $('.main-body').scrollTop();
        if (state > 200) {
            $(".scroll-to-top").fadeIn('slow');
        }
        if (state < 200) {
            $(".scroll-to-top").fadeOut('slow');
        }
    });
    $(".scroll-to-top").on("click", function(e) {
        e.preventDefault();
        $("body,html,document").animate({
            scrollTop: 0
        }, 1000);

        $(".main-body").animate({
            scrollTop: 0
        }, 1000);
    });
    /* End Scroll Top */

});