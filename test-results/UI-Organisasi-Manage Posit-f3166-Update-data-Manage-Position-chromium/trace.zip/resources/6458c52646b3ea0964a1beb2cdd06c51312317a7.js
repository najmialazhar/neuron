
$.toast = function(opt){
    $.nAlert(opt);
}

$.nAlert = function(opt){
    bootbox.alert(opt.content);
}