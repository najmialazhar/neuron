$(document).ready(function () {
    /* home url */
    var home = $('meta[name="homeurl"]').attr('content');
    if (home == undefined) home = window.location.href;

    var isOpenPanel = false;

    $('.open-my-panel').click(function () {

        if (isOpenPanel == false) {
            $(".select-able-roles").removeClass("hidden");
            setTimeout(() => {
                $(".select-able-roles").removeClass("inactive");
                $(".select-able-roles").removeClass("active");
                $(".my-arrow-left").removeClass("active");

                $(".select-able-roles").addClass("active");
                $(".my-arrow-left").addClass("active");
            }, 300);

        } else {
            $(".select-able-roles").addClass("inactive");
            setTimeout(() => {
                $(".my-arrow-left").removeClass("active");
                $(".select-able-roles").addClass("hidden");
            }, 500);
        }

        isOpenPanel = !isOpenPanel;
    });

    $('.change-my-role-please').click(function () {
        var roleId = $(this).attr('attr-role');
        var thisId = '#custom-my-toggle-' + roleId;
        $.ajax({
            url: home + "/idmt/index/change-my-role",
            type: "POST",
            data: {
                role: roleId
            },
            success: function (res) {
                if (res.data == true) {
                    $('.custom-my-toggle input').each(function (e) {
                        var checkId = '#' + $(this).attr('id');
                        if (checkId != thisId) {

                            $('.custom-my-toggle input' + checkId).removeAttr('checked');
                            $(".custom-my-toggle input" + checkId).prop("checked", false);
                        }
                    });

                    $('.custom-my-toggle-desc').removeClass('active');

                    setTimeout(() => {
                        $(this).attr('checked', 'checked');
                        $('#custom-my-toggle-' + roleId).prop("checked", true);
                        $('.custom-my-toggle-desc-' + roleId).addClass('active');
                        setTimeout(() => {
                            window.location.href = home + '/idmt';
                        }, 500);
                    }, 1000);
                } else {
                    $(this).attr('checked', 'checked');
                    $('#custom-my-toggle-' + roleId).prop("checked", true);
                    $('.custom-my-toggle-desc-' + roleId).addClass('active');
                }
            }
        });
    })
});