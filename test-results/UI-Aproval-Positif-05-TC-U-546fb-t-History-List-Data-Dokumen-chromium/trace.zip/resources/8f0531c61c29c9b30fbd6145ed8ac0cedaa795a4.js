$(document).ready(function () {
    /* home url */
    var home = $('meta[name="homeurl"]').attr('content');
    if (home == undefined) home = window.location.href;

    setTimeout(() => {
        $.ajax({
            url: home + "/idmt/approval/list-count",
            type: "POST",
            success: function (res) {
                var targetNotification = document.querySelectorAll('button#btn_notification > span.badge.badge-pill');
                targetNotification[0].innerHTML = res.recordsFiltered;
            }
        });
    }, 10000);
});